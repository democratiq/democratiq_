
import Page from "@/app/dashboard/page";

export default function Home() {
  return (
      <Page></Page>
  )
}
